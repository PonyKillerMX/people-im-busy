"""This is the main folder to implement the application"""
